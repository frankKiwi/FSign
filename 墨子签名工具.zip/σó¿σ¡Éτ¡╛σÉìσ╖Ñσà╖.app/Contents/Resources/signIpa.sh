
IPAPath=$1
MobieProvision=$2

ConfigHear=~/Desktop
ConfigTarget=$ConfigHear/Mozi/resigned

SH1=$3

W_STARTTIME=$(date +%s)
sh ./signRename.sh $IPAPath
echo "SH1: "$SH1""

softfiles=$(ls $IPAPath)
for sfile in ${softfiles}
do 

echo "包: ${sfile}"

echo "早游戏墨子:即将保持原bundleID进行打包"
sh ./resign.sh $IPAPath/${sfile} $MobieProvision "$SH1"
STARTTIME=$(date +%s)

done

W_ENDTIME=$(date +%s)

echo "Sign total cost time: "$((W_ENDTIME-W_STARTTIME))"s"

open $ConfigTarget


